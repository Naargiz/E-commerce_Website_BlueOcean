let searchForm = document.querySelector('.search-form');
/*
document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
}*/
function search_button() {
    if(document.getElementById("form_action").style.display=="block") {
        document.getElementById("form_action").style.display = "none"
    }else{
        document.getElementById("form_action").style.display="block"
    }
}